@echo off
echo.
echo Four Seasons - Desktop Shortcut Creator
echo ======================================
echo.

set SCRIPT_DIR=%~dp0
set DESKTOP=%USERPROFILE%\Desktop
set SHORTCUT_NAME=Four Seasons

echo Creating desktop shortcut...

rem Create VBS script to generate shortcut
(
echo Set oWS = WScript.CreateObject^("WScript.Shell"^)
echo sLinkFile = "%DESKTOP%\%SHORTCUT_NAME%.lnk"
echo Set oLink = oWS.CreateShortcut^(sLinkFile^)
echo oLink.TargetPath = "%SCRIPT_DIR%FourSeasons.bat"
echo oLink.WorkingDirectory = "%SCRIPT_DIR%"
echo oLink.Description = "Four Seasons - Multiplayer Chess Variant"
echo oLink.IconLocation = "%SCRIPT_DIR%FourSeasons.jar,0"
echo oLink.Save
) > "%TEMP%\create_shortcut.vbs"

rem Execute the VBS script
cscript //nologo "%TEMP%\create_shortcut.vbs"

rem Clean up
del "%TEMP%\create_shortcut.vbs" >nul 2>&1

if exist "%DESKTOP%\%SHORTCUT_NAME%.lnk" (
    echo SUCCESS: Desktop shortcut created!
    echo.
    echo You can now double-click "%SHORTCUT_NAME%" on your desktop to play.
    echo.
    echo Alternative launch methods:
    echo - Double-click FourSeasons.bat ^(shows console^)
    echo - Double-click FourSeasons-Silent.vbs ^(no console^)
    echo - Right-click FourSeasons.ps1 -^> "Run with PowerShell"
) else (
    echo ERROR: Failed to create desktop shortcut.
    echo Try running this script as Administrator.
)

echo.
pause
