' Four Seasons Silent Launcher for Windows
' Launches the game without showing a command prompt window
' Useful for desktop shortcuts and Start menu entries

Dim objShell, objFSO, strScriptPath, strCommand, intReturn

Set objShell = CreateObject("WScript.Shell")
Set objFSO = CreateObject("Scripting.FileSystemObject")

' Get the directory where this script is located
strScriptPath = objFSO.GetParentFolderName(WScript.ScriptFullName)

' Change to the application directory
objShell.CurrentDirectory = strScriptPath

' Check if Java is available (basic check)
intReturn = objShell.Run("java -version", 0, True)
If intReturn <> 0 Then
    MsgBox "Java is not installed or not available in PATH." & vbCrLf & vbCrLf & _
           "Please install Java 11 or later from:" & vbCrLf & _
           "https://adoptium.net/", vbCritical, "Four Seasons - Java Required"
    WScript.Quit 1
End If

' Build the Java command for Windows
strCommand = "java " & _
    "-Dfile.encoding=UTF-8 " & _
    "-Djava.awt.headless=false " & _
    "-Dprism.verbose=false " & _
    "-Djavafx.animation.fullspeed=true " & _
    "-Dsun.java2d.dpiaware=true " & _
    "--module-path lib " & _
    "--add-modules javafx.controls,javafx.fxml " & _
    "--add-exports javafx.base/com.sun.javafx.event=ALL-UNNAMED " & _
    "-jar FourSeasons.jar"

' Run the command (0 = hidden console, False = don't wait)
' The application will run independently
objShell.Run strCommand, 0, False

' Cleanup
Set objShell = Nothing
Set objFSO = Nothing
