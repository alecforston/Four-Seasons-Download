@echo off
setlocal enabledelayedexpansion

:: Four Seasons Windows Launcher
:: Built for Windows 7, 8, 8.1, 10, and 11

title Four Seasons - Multiplayer Chess Variant
cd /d "%~dp0"

echo.
echo ==========================================
echo   Four Seasons - Multiplayer Chess
echo   Version 0.6.1 - Windows Edition
echo ==========================================
echo.

:: Check if Java is available
echo [INFO] Checking Java installation...
java -version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Java is not installed or not in PATH
    echo.
    echo Java 11 or later is required to run Four Seasons.
    echo.
    echo Please download and install Java from:
    echo   https://adoptium.net/
    echo   https://www.oracle.com/java/technologies/downloads/
    echo.
    echo Or install via package manager:
    echo   winget install Microsoft.OpenJDK.11
    echo   choco install openjdk11
    echo.
    echo After installation, restart this application.
    goto :error_exit
)

:: Get Java version with better parsing
for /f "tokens=3" %%g in ('java -version 2^>^&1 ^| findstr /i "version"') do (
    set JAVA_VERSION_STRING=%%g
)

:: Remove quotes from version string
set JAVA_VERSION_STRING=%JAVA_VERSION_STRING:"=%

:: Parse major version number (handle both old 1.8 format and new 11+ format)
for /f "delims=. tokens=1-3" %%v in ("%JAVA_VERSION_STRING%") do (
    if "%%v"=="1" (
        set JAVA_MAJOR=%%w
    ) else (
        set JAVA_MAJOR=%%v
    )
)

:: Validate Java version
if %JAVA_MAJOR% LSS 11 (
    echo [ERROR] Java version is too old: %JAVA_VERSION_STRING%
    echo Java 11 or later is required.
    echo Current major version detected: %JAVA_MAJOR%
    echo.
    echo Please update Java from:
    echo   https://adoptium.net/
    echo   https://www.oracle.com/java/technologies/downloads/
    goto :error_exit
)

echo [INFO] Java version: %JAVA_VERSION_STRING% ^(Major: %JAVA_MAJOR%^) - OK
echo [INFO] Checking required files...

:: Check for required files
if not exist "FourSeasons.jar" (
    echo [ERROR] FourSeasons.jar not found!
    echo Make sure all files are in the same directory.
    goto :error_exit
)

if not exist "lib\" (
    echo [ERROR] lib\ directory not found!
    echo Make sure all files are extracted properly.
    goto :error_exit
)

if not exist "lib\javafx.controls.jar" (
    echo [ERROR] JavaFX libraries not found in lib\ directory!
    echo Make sure the package was extracted completely.
    goto :error_exit
)

echo [INFO] All required files found - OK
echo [INFO] Starting Four Seasons...
echo.

:: Run the application with Windows-optimized settings
java -Dfile.encoding=UTF-8 ^
     -Djava.awt.headless=false ^
     -Dprism.verbose=false ^
     -Djavafx.animation.fullspeed=true ^
     -Dsun.java2d.dpiaware=true ^
     --module-path lib ^
     --add-modules javafx.controls,javafx.fxml ^
     --add-exports javafx.base/com.sun.javafx.event=ALL-UNNAMED ^
     -jar FourSeasons.jar

set EXIT_CODE=%errorlevel%

if %EXIT_CODE% neq 0 (
    echo.
    echo [ERROR] Application exited with error code %EXIT_CODE%
    echo.
    echo Common solutions:
    echo - Make sure all files are in the same folder
    echo - Check that lib\ folder contains all required JAR files
    echo - Ensure Windows Defender isn't blocking the application
    echo - Try running as Administrator
    echo - Check Windows Event Viewer for detailed error info
    echo.
    goto :error_exit
) else (
    echo.
    echo [INFO] Four Seasons closed normally.
    echo.
)

goto :end

:error_exit
echo.
pause
exit /b 1

:end
endlocal
