@echo off
echo.
echo Four Seasons - Start Menu Shortcut Creator
echo =========================================
echo.

set SCRIPT_DIR=%~dp0
set START_MENU=%APPDATA%\Microsoft\Windows\Start Menu\Programs
set SHORTCUT_NAME=Four Seasons

echo Creating Start Menu shortcut...

rem Create VBS script to generate shortcut
(
echo Set oWS = WScript.CreateObject^("WScript.Shell"^)
echo sLinkFile = "%START_MENU%\%SHORTCUT_NAME%.lnk"
echo Set oLink = oWS.CreateShortcut^(sLinkFile^)
echo oLink.TargetPath = "%SCRIPT_DIR%FourSeasons-Silent.vbs"
echo oLink.WorkingDirectory = "%SCRIPT_DIR%"
echo oLink.Description = "Four Seasons - Multiplayer Chess Variant"
echo oLink.IconLocation = "%SCRIPT_DIR%FourSeasons.jar,0"
echo oLink.Save
) > "%TEMP%\create_startmenu.vbs"

rem Execute the VBS script
cscript //nologo "%TEMP%\create_startmenu.vbs"

rem Clean up
del "%TEMP%\create_startmenu.vbs" >nul 2>&1

if exist "%START_MENU%\%SHORTCUT_NAME%.lnk" (
    echo SUCCESS: Start Menu shortcut created!
    echo.
    echo You can now find "Four Seasons" in your Start Menu.
    echo The shortcut will launch the game silently ^(no console window^).
) else (
    echo ERROR: Failed to create Start Menu shortcut.
    echo Try running this script as Administrator.
)

echo.
pause
