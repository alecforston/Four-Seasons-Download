# Four Seasons PowerShell Launcher for Windows
# Requires PowerShell 3.0+ (Windows 8/Server 2012+)

param(
    [switch]$NoWait,
    [switch]$Debug
)

# Set console properties
$Host.UI.RawUI.WindowTitle = "Four Seasons - Multiplayer Chess"
$ErrorActionPreference = "Stop"

# Console colors
$InfoColor = "Green"
$ErrorColor = "Red"
$WarningColor = "Yellow"

Write-Host ""
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host " Four Seasons - Multiplayer Chess" -ForegroundColor Cyan
Write-Host " Version 0.6.1 - Windows Edition" -ForegroundColor Cyan
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host ""

# Change to script directory
Set-Location $PSScriptRoot

Write-Host "[INFO] Checking Java installation..." -ForegroundColor $InfoColor

# Check for Java
try {
    $javaVersionOutput = & java -version 2>&1
    if ($LASTEXITCODE -ne 0) {
        throw "Java executable not found in PATH"
    }

    # Parse Java version
    $versionLine = ($javaVersionOutput | Where-Object { $_ -match "version" } | Select-Object -First 1)
    if ($versionLine -match '"([^"]*)"') {
        $versionString = $matches[1]
    } else {
        throw "Could not parse Java version"
    }

    # Extract major version
    if ($versionString -match "^1\.(\d+)") {
        $majorVersion = [int]$matches[1]
    } elseif ($versionString -match "^(\d+)") {
        $majorVersion = [int]$matches[1]
    } else {
        throw "Could not determine Java major version from: $versionString"
    }

    if ($majorVersion -lt 11) {
        throw "Java version too old: $versionString (major: $majorVersion). Java 11+ required."
    }

    Write-Host "[INFO] Java version: $versionString (Major: $majorVersion) - OK" -ForegroundColor $InfoColor

} catch {
    Write-Host "[ERROR] $($_.Exception.Message)" -ForegroundColor $ErrorColor
    Write-Host ""
    Write-Host "Java 11 or later is required to run Four Seasons." -ForegroundColor $WarningColor
    Write-Host ""
    Write-Host "Download options:" -ForegroundColor $WarningColor
    Write-Host "• https://adoptium.net/ (Recommended)" -ForegroundColor $WarningColor
    Write-Host "• https://www.oracle.com/java/technologies/downloads/" -ForegroundColor $WarningColor
    Write-Host ""
    Write-Host "Package manager options:" -ForegroundColor $WarningColor
    Write-Host "• winget install Microsoft.OpenJDK.11" -ForegroundColor $WarningColor
    Write-Host "• choco install openjdk11" -ForegroundColor $WarningColor
    Write-Host ""
    if (-not $NoWait) {
        Read-Host "Press Enter to continue"
    }
    exit 1
}

Write-Host "[INFO] Checking required files..." -ForegroundColor $InfoColor

# Check required files
$requiredFiles = @(
    "FourSeasons.jar",
    "lib\javafx.controls.jar",
    "lib\javafx.fxml.jar",
    "lib\gson-2.10.1.jar"
)

$missingFiles = @()
foreach ($file in $requiredFiles) {
    if (-not (Test-Path $file)) {
        $missingFiles += $file
    }
}

if ($missingFiles.Count -gt 0) {
    Write-Host "[ERROR] Missing required files:" -ForegroundColor $ErrorColor
    foreach ($file in $missingFiles) {
        Write-Host "  - $file" -ForegroundColor $ErrorColor
    }
    Write-Host ""
    Write-Host "Please ensure the package was extracted completely." -ForegroundColor $WarningColor
    if (-not $NoWait) {
        Read-Host "Press Enter to continue"
    }
    exit 1
}

Write-Host "[INFO] All required files found - OK" -ForegroundColor $InfoColor
Write-Host "[INFO] Starting Four Seasons..." -ForegroundColor $InfoColor
Write-Host ""

# Build Java arguments
$javaArgs = @(
    '-Dfile.encoding=UTF-8'
    '-Djava.awt.headless=false'
    '-Dprism.verbose=false'
    '-Djavafx.animation.fullspeed=true'
    '-Dsun.java2d.dpiaware=true'
)

if ($Debug) {
    $javaArgs += @(
        '-Dprism.verbose=true'
        '-Djavafx.verbose=true'
    )
}

$javaArgs += @(
    '--module-path', 'lib'
    '--add-modules', 'javafx.controls,javafx.fxml'
    '--add-exports', 'javafx.base/com.sun.javafx.event=ALL-UNNAMED'
    '-jar', 'FourSeasons.jar'
)

# Launch the application
try {
    & java $javaArgs
    $exitCode = $LASTEXITCODE

    if ($exitCode -ne 0) {
        Write-Host ""
        Write-Host "[ERROR] Application exited with error code $exitCode" -ForegroundColor $ErrorColor
        Write-Host ""
        Write-Host "Troubleshooting steps:" -ForegroundColor $WarningColor
        Write-Host "• Make sure all files are in the same folder" -ForegroundColor $WarningColor
        Write-Host "• Check Windows Defender exclusions" -ForegroundColor $WarningColor
        Write-Host "• Try running as Administrator" -ForegroundColor $WarningColor
        Write-Host "• Check Windows Event Viewer for details" -ForegroundColor $WarningColor
        Write-Host "• Try the Debug flag: .\FourSeasons.ps1 -Debug" -ForegroundColor $WarningColor
    } else {
        Write-Host ""
        Write-Host "[INFO] Four Seasons closed normally." -ForegroundColor $InfoColor
    }
} catch {
    Write-Host "[ERROR] Failed to start application: $($_.Exception.Message)" -ForegroundColor $ErrorColor
}

if (-not $NoWait) {
    Write-Host ""
    Read-Host "Press Enter to continue"
}
