# Four Seasons - Windows Edition v0.6.1

A four-player chess variant with network multiplayer support, optimized for Windows.

## 🚀 Quick Start Guide

### **Method 1: Batch File (Recommended for most users)**
1. Double-click `FourSeasons.bat`
2. Console window shows startup progress and any errors
3. Game launches automatically

### **Method 2: Silent Launch (Clean desktop experience)**
1. Double-click `FourSeasons-Silent.vbs`
2. Game starts without showing console window
3. Best for desktop shortcuts

### **Method 3: PowerShell (Advanced users)**
1. Right-click `FourSeasons.ps1` → "Run with PowerShell"
2. Most detailed error reporting and diagnostics
3. Supports debug mode: `.\FourSeasons.ps1 -Debug`

### **Method 4: Create Shortcuts**
- **Desktop**: Run `Create-Desktop-Shortcut.bat`
- **Start Menu**: Run `Create-StartMenu-Shortcut.bat`

## 📋 System Requirements

- **Windows**: 7, 8, 8.1, 10, or 11 (32-bit or 64-bit)
- **Java**: Version 11 or later (JRE or JDK)
- **Memory**: 1GB RAM minimum, 2GB recommended
- **Storage**: 150MB free space
- **Graphics**: DirectX 9.0c compatible
- **Network**: Internet connection for multiplayer

## ☕ Java Installation & Setup

### **Quick Check**
Open Command Prompt and type:
```cmd
java -version
```

If you see version 11 or higher, you're ready to play!

### **Installation Options**

#### **Option 1: Adoptium (Recommended)**
1. Visit: https://adoptium.net/
2. Click "Latest LTS" → "JDK" → "Windows"
3. Download and run the installer
4. Restart Four Seasons

#### **Option 2: Microsoft OpenJDK**
```cmd
winget install Microsoft.OpenJDK.11
```

#### **Option 3: Oracle Java**
1. Visit: https://www.oracle.com/java/technologies/downloads/
2. Download Java 11+ for Windows
3. Run installer and follow prompts

#### **Option 4: Chocolatey**
```cmd
choco install openjdk11
```

## 🎮 How to Play

### **Local Game (Single Computer)**
1. Launch Four Seasons
2. Game starts in local mode by default
3. Click pieces to select them
4. Click destination squares to move
5. Turn order: Spring (Green) → Summer (Red) → Fall (Blue) → Winter (White)

### **Network Multiplayer**
1. **Start**: Menu → Game → Network Game
2. **Host Setup**:
   - Choose "Connect to Network"
   - Use "localhost" for same-computer testing
   - Use your IP address for LAN games
3. **Create/Join**:
   - "Create Game" and share the Game ID
   - Or "Join Game" with someone else's Game ID
4. **Wait**: Game starts when all 4 players connect

## 🔧 Troubleshooting

### **Java Issues**

#### **"Java is not recognized as an internal or external command"**
- Java is not installed or not in PATH
- Install from https://adoptium.net/
- Restart computer after installation

#### **"Java version is too old"**
- Current Java is version 8 or older
- Update to Java 11+ from https://adoptium.net/
- May need to uninstall old Java first

### **Application Issues**

#### **"Application won't start" or "Error code"**
1. Run `FourSeasons.bat` to see detailed error messages
2. Make sure all files are in the same directory
3. Try "Run as Administrator"
4. Check Windows Event Viewer (eventvwr.msc)

#### **Windows Defender / SmartScreen warnings**
1. Click "More info" → "Run anyway"
2. Or add the folder to Windows Defender exclusions:
   - Settings → Update & Security → Windows Security
   - Virus & threat protection → Exclusions → Add folder

#### **Missing files errors**
- Ensure you extracted the complete archive
- Re-download if files are missing
- Check that lib/ folder contains JAR files

### **Performance Issues**

#### **Game runs slowly**
- Close other applications
- Update graphics drivers
- Use `FourSeasons.ps1 -Debug` to check for issues

#### **High DPI display problems**
- Windows should handle this automatically
- If issues persist, try: Right-click → Properties → Compatibility → "Override high DPI scaling behavior"

### **Network/Multiplayer Issues**

#### **Can't connect to games**
- Check Windows Firewall settings
- Allow Java through firewall when prompted
- For local testing, use "localhost"
- For internet play, check router port forwarding

#### **Firewall Configuration**
1. Windows Key + R → `wf.msc`
2. "Inbound Rules" → "New Rule"
3. Allow Java through ports 8889-8890

## 📁 File Structure

```
fourseasons-multiplayer-v0.6.1-windows/
├── FourSeasons.jar                    # Main application
├── FourSeasons.bat                    # Primary launcher (console)
├── FourSeasons.ps1                    # PowerShell launcher (advanced)
├── FourSeasons-Silent.vbs             # Silent launcher (no console)
├── Create-Desktop-Shortcut.bat        # Desktop shortcut creator
├── Create-StartMenu-Shortcut.bat      # Start Menu shortcut creator
├── Uninstall.bat                      # Uninstaller utility
├── lib/                               # Required libraries
│   ├── javafx.controls.jar           # JavaFX UI controls
│   ├── javafx.fxml.jar               # JavaFX FXML support
│   ├── gson-2.10.1.jar               # JSON processing
│   └── [other JavaFX libraries]
├── README-Windows.md                  # This comprehensive guide
└── VERSION                           # Build information
```

## 🛡️ Security & Privacy

### **Why Windows shows security warnings:**
- This is an unsigned application (normal for indie games)
- Windows SmartScreen protects against unknown software
- The game is safe - source code is available for review

### **Data Collection:**
- ❌ No telemetry or analytics
- ❌ No personal data collected
- ❌ No internet access except for multiplayer gaming
- ✅ All game data stays on your computer

## 🔄 Updates & Maintenance

### **Updating Four Seasons:**
1. Download the new version
2. Extract to a new folder
3. Copy any save files from old version (if applicable)
4. Run the new version

### **Keeping Java Updated:**
- Check https://adoptium.net/ periodically
- Or use Windows Update (for Microsoft OpenJDK)

## 🗑️ Uninstalling

### **Remove Shortcuts Only:**
1. Double-click `Uninstall.bat`
2. Follow the prompts

### **Complete Removal:**
1. Run `Uninstall.bat` first
2. Delete the entire Four Seasons folder
3. Check `%USERPROFILE%\.fourseasons` for save data (if any)

## 📞 Support & Help

### **Getting Help:**
1. **First**: Try the PowerShell launcher for detailed error messages
2. **Check**: Windows Event Viewer (eventvwr.msc) for system errors
3. **Verify**: Java installation with `java -version`
4. **Test**: Local game first, then network features

### **Common Command Line Diagnostics:**
```cmd
# Check Java version
java -version

# List Java system properties
java -XshowSettings:properties -version

# Test JavaFX availability
java --module-path lib --list-modules
```

## 🏆 Advanced Features

### **Command Line Options:**
```cmd
# Debug mode with verbose output
.\FourSeasons.ps1 -Debug

# Silent PowerShell execution
.\FourSeasons.ps1 -NoWait
```

### **Custom Java Options:**
Edit the batch/PowerShell files to add:
- `-Xmx2G` for more memory
- `-Dprism.order=sw` for software rendering
- `-Dfile.encoding=UTF-8` for character encoding

---

**Windows-Optimized Features:**
- ✅ Multiple launch methods (Batch, PowerShell, VBS)
- ✅ Comprehensive Java detection and validation
- ✅ Desktop and Start Menu shortcut creators
- ✅ Windows Defender compatibility guidance
- ✅ High DPI display support
- ✅ Detailed error reporting and troubleshooting
- ✅ Clean uninstaller with shortcut removal
- ✅ Silent launch option for clean desktop experience

**Enjoy Four Seasons on Windows!** 🪟♟️
