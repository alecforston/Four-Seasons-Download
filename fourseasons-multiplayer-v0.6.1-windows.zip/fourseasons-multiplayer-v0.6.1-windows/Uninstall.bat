@echo off
echo.
echo Four Seasons - Uninstaller
echo ==========================
echo.
echo This will remove Four Seasons shortcuts from your system.
echo Your game files and settings will NOT be deleted automatically.
echo.

set /p CONFIRM="Are you sure you want to uninstall shortcuts? (y/N): "

if /i not "%CONFIRM%"=="y" (
    echo.
    echo Uninstall cancelled.
    pause
    exit /b 0
)

echo.
echo Removing shortcuts...

rem Remove desktop shortcut
if exist "%USERPROFILE%\Desktop\Four Seasons.lnk" (
    del "%USERPROFILE%\Desktop\Four Seasons.lnk" >nul 2>&1
    echo - Desktop shortcut removed
) else (
    echo - No desktop shortcut found
)

rem Remove Start Menu shortcut
if exist "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Four Seasons.lnk" (
    del "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Four Seasons.lnk" >nul 2>&1
    echo - Start Menu shortcut removed
) else (
    echo - No Start Menu shortcut found
)

echo.
echo Shortcut removal complete!
echo.
echo To completely remove Four Seasons:
echo 1. Delete this entire folder: %~dp0
echo 2. Check %%USERPROFILE%%\.fourseasons for save data ^(if any^)
echo.
echo Thank you for playing Four Seasons!
pause
