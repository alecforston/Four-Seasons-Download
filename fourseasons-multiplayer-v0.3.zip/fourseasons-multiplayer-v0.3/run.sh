#!/bin/bash

# Four Seasons Multiplayer Game Launcher
cd "$(dirname "$0")"

# Check if Java is available
if ! command -v java &> /dev/null; then
    echo "Java is not installed or not in PATH"
    echo "Please install Java 11 or later"
    exit 1
fi

# Get Java version
JAVA_VERSION=$(java -version 2>&1 | head -1 | cut -d'"' -f2 | sed '/^1\./s///' | cut -d'.' -f1)
if [ "$JAVA_VERSION" -lt 11 ]; then
    echo "Java 11 or later is required"
    echo "Current version: $(java -version 2>&1 | head -1)"
    exit 1
fi

# Run the application
java --module-path lib \
     --add-modules javafx.controls,javafx.fxml \
     --add-exports javafx.base/com.sun.javafx.event=ALL-UNNAMED \
     -jar FourSeasons.jar "$@"
