# Four Seasons - Multiplayer Chess Variant v0.3

A four-player chess variant with network multiplayer support using DHT (Distributed Hash Table).

## System Requirements

- Java 11 or later
- JavaFX (included in this package)
- 1GB RAM minimum
- Network connection for multiplayer

## How to Run

### Linux/macOS:
```bash
./run.sh
```

### Windows:
Double-click `run.bat` or run from command prompt:
```
run.bat
```

## Quick Start

### Local Game:
1. Launch the application
2. The game starts in local mode by default
3. Click pieces to select and move them
4. Players take turns: Spring → Summer → Fall → Winter

### Network Multiplayer:
1. Go to Game → Network Game
2. Choose "Connect to Network" (use "localhost" if testing on same machine)
3. Create a new game or join an existing one using Game ID
4. Wait for other players to join
5. Game starts automatically when all 4 players are connected

## Game Rules

Four Seasons is played on an 8x8 board with four players in the corners:
- **Spring (Green)**: Top-right corner, moves left/down
- **Summer (Red)**: Top-left corner, moves right/down  
- **Fall (Blue)**: Bottom-left corner, moves right/up
- **Winter (White)**: Bottom-right corner, moves left/up

### Pieces:
- **King**: Moves one square in any direction
- **Rook**: Moves along rows and columns
- **Knight**: Moves in L-shapes
- **Elephant**: Moves exactly two squares diagonally
- **Pawn**: Moves forward one square, captures perpendicular to movement direction
- **General**: Promoted pawn, moves one square diagonally

### Victory Conditions:
The game continues until only one player has pieces remaining, or a king is captured.

## Network Architecture

This game uses a peer-to-peer DHT network:
- No central server required
- Players connect directly to each other
- Games are discovered through the distributed hash table
- Built-in chat system for communication

## Troubleshooting

### "Java not found" error:
- Install Java 11 or later from https://adoptium.net/
- Make sure Java is in your system PATH

### Network connection issues:
- Check firewall settings (ports 8889-8890)
- For local testing, use "localhost" as bootstrap host
- For internet play, one player needs a public IP or port forwarding

### Game not starting:
- Make sure all required files are in the same directory
- Check that JavaFX libraries are present in the lib/ folder

## File Structure
```
fourseasons-multiplayer-v0.3/
├── FourSeasons.jar          # Main application
├── lib/                     # JavaFX libraries
├── run.sh                   # Linux/macOS launcher
├── run.bat                  # Windows launcher
└── README.md               # This file
```

## Support

For issues or questions, check the source code documentation or create an issue in the project repository.

Enjoy playing Four Seasons!
