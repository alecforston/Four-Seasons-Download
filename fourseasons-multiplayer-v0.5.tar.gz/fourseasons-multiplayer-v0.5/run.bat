@echo off
cd /d "%~dp0"

echo Starting Four Seasons Multiplayer...

rem Check if Java is available
java -version >nul 2>&1
if %errorlevel% neq 0 (
    echo Java is not installed or not in PATH
    echo Please install Java 11 or later
    pause
    exit /b 1
)

rem Run the application
java --module-path lib --add-modules javafx.controls,javafx.fxml --add-exports javafx.base/com.sun.javafx.event=ALL-UNNAMED -jar FourSeasons.jar %*

if %errorlevel% neq 0 (
    echo Application exited with error code %errorlevel%
    pause
)
